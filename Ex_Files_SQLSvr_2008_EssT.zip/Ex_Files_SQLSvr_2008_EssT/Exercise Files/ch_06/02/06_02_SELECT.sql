
SELECT * FROM AdventureWorksLT.SalesLT.Customer

USE AdventureWorksLT
SELECT * FROM SalesLT.Customer

USE AdventureWorksLT
SELECT FirstName, LastName, EmailAddress 
FROM SalesLT.Customer

USE AdventureWorksLT
SELECT FirstName + ' ' + LastName AS FullName, EmailAddress 
FROM SalesLT.Customer

USE AdventureWorksLT
SELECT FirstName + ' ' + LastName AS FullName, EmailAddress 
FROM SalesLT.Customer

