EXEC dbo.uspCreateModelAndDescription 
'GHI123','GHI123 product description'