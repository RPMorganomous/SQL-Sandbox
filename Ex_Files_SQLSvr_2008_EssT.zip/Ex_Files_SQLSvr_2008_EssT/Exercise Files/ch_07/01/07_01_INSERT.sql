USE AdventureWorksLT

-- single row insert
INSERT INTO SalesLT.ProductCategory
(ParentProductCategoryID, Name)
VALUES (1,'Hybrid Bikes')

-- multiple rows
INSERT INTO SalesLT.ProductCategory
(ParentProductCategoryID, Name)
VALUES (1,'Girl''s Bikes'),(1,'Boy''s Bikes')


