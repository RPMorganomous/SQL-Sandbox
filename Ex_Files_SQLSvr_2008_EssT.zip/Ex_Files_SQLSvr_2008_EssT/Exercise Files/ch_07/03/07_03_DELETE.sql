USE AdventureWorksLT

-- DELETE FROM table WHERE condition

-- ALWAYS , ALWAYS have a WHERE!
DELETE from SalesLT.ProductCategory 
WHERE ProductCategoryID > 41